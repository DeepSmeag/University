﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Curs12_LINQ
{
    internal class Student
    {
        public Student(string nume, int nota)
        {
            Nume = nume;
            Nota = nota;
        }

        public string Nume { get; set; }
        public int Nota { get; set; }

        public override string? ToString()
        {
            return this.Nume + " " + this.Nota;
        }
    }
}
