﻿namespace Curs12_LINQ
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Cerinte:
            // 1. Determinati cuvintele care sunt scrise cu litere mari dintr-un text dat
            String text = "ACESTA Este UN Text MARE";

            // Varianta 1
            var cuvinteMari = text.Split(" ")
                .Where(x => x.ToUpper().Equals(x)) // filter in java
                .ToList(); // collectors in java - operatie terminala
            cuvinteMari.ForEach(Console.WriteLine);

            Console.WriteLine();

            // Varianta 2
            var cuvinteMari2 = from cuvant in text.Split(" ")
                               where cuvant.ToUpper().Equals(cuvant)
                               select cuvant; // map in java
            cuvinteMari2.ToList().ForEach(Console.WriteLine);

            Console.WriteLine();

            // 2. Afisati numerele si frecventele lor de aparitie dintr-un sir de numere
            int[] numbers = { 1, 1, 2, 0, 10, -2, -2, 10, 0, 2, 3, 4, 10, -2, 0, 1, 1 };

            // Varianta 1
            var numFreq = numbers.GroupBy(x => x)
                .Select(x => new { Number = x.Key, Count = x.Count() })
                .OrderBy(x => x.Number)
                .ToList();
            numFreq.ForEach(x => Console.WriteLine(x.Number + ": " + x.Count));

            Console.WriteLine();

            // Varianta 2
            var numFreq2 = from number in numbers
                           group number by number into groupedNums
                           select new { Number = groupedNums.Key, Count = groupedNums.Count() } into numberFreq
                           orderby numberFreq.Number
                           select numberFreq;
            numFreq2.ToList().ForEach(x => Console.WriteLine(x.Number + ": " + x.Count));

            Console.WriteLine();

            // 3. Entitate Studet(nume: string, nota: int)
            // Sortam o lista de studenti dupa nota descrescator, iar la note egale alfabetic dupa nume
            IList<Student> students = new List<Student>();
            students.Add(new Student("Alex", 10));
            students.Add(new Student("Mihai", 7));
            students.Add(new Student("Maria", 9));
            students.Add(new Student("Ioana", 10));

            // Varianta 1
            var sortedStudents = students.OrderByDescending(x => x.Nota)
                .ThenBy(x => x.Nume)
                .ToList();
            sortedStudents.ForEach(Console.WriteLine);

            Console.WriteLine();

            // Varianta 2
            var sortedStudents2 = from student in students
                                  orderby student.Nota descending, student.Nume ascending
                                  select student;
            sortedStudents2.ToList().ForEach(Console.WriteLine);
        }
    }
}