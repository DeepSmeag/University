package ro.ubbcluj.scs.map.character;

public interface CanPlay {
    void play();
}
