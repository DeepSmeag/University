package ro.ubbcluj.scs.map.character;

public interface CanTalk extends CanPlay {
    void talk();
}
