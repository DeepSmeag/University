package ro.ubbcluj.scs.map.character;

public interface CanFly extends CanPlay {
    void fly();
}
