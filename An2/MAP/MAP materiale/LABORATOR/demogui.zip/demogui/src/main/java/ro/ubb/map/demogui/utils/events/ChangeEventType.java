package ro.ubb.map.demogui.utils.events;

public enum ChangeEventType {
    ADD,UPDATE,DELETE;
}
