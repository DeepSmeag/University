package ro.ubb.map.demogui.repository.paging;
public interface Pageable {
    int getPageNumber();
    int getPageSize();
}
