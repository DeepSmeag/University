package com.example.restaurante.utils.utils;

public enum ChangeEventType {
    ADD, UPDATE
}
