package com.example.restaurante.repository.factory;

public enum RepositoryType {
    MEMORY, FILE, DATABASE
}