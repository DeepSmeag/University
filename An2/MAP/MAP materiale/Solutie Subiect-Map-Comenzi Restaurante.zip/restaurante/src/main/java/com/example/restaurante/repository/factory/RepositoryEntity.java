package com.example.restaurante.repository.factory;

public enum RepositoryEntity {
    TABLES, MENUITEMS, ORDERS
}
