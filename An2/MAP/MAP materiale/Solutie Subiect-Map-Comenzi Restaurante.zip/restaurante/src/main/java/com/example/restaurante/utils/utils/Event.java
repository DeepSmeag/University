package com.example.restaurante.utils.utils;

public interface Event {
}
