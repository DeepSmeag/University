package com.example.restaurante.domain;

public enum OrderStatus {
    PLACED, PREPARING, SERVED
}
