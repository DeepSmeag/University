package models.validators;

import models.Student;

public class StudentValidator implements Validator<Student>{

    @Override
    public void validate(Student entity) throws ValidationException {
        //TODO: actually implement this, maybe. (temă)
    }
}
