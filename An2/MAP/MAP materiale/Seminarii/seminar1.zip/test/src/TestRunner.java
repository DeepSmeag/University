import model.MessageTask;

import java.time.LocalDateTime;

public class TestRunner {

    public static MessageTask[] CreateMessageTasks(){
        MessageTask m1 = new MessageTask("1", "teme laborator",
                "ai primit o tema de laborator", "George", "Maria",
                LocalDateTime.now());
        MessageTask m2 = new MessageTask("2", "teme laborator",
                "ai o tema de seminar", "Mihai", "Maria",
                LocalDateTime.now());
        MessageTask m3 = new MessageTask("3", "teme seminar",
                "ai primit o tema de seminar", "George", "Andrei",
                LocalDateTime.now());
        return new MessageTask[]{m1, m2, m3};
    }

    public static void Run(){
        MessageTask[] lista = CreateMessageTasks();
        for(MessageTask messageTask : lista)
        {
            messageTask.execute();
        }
    }
}
