import java.util.Scanner;
import model.MessageTask;

public class Main {
    public static void main(String[] args) {
        TestRunner.Run();
    }
}