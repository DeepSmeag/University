package functionalInterface;

@FunctionalInterface
public interface Area<E> {
    float computeArea(E e);
}
