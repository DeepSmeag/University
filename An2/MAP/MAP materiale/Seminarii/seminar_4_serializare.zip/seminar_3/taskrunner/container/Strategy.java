package ubb.scs.map.ir.seminar.taskrunner.container;

public enum Strategy {
    LIFO,
    FIFO
}
