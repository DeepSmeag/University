package ubb.scs.map.ir.seminar.studentsmanagement.repository;


import ubb.scs.map.ir.seminar.studentsmanagement.domain.Student;
import ubb.scs.map.ir.seminar.studentsmanagement.domain.validators.Validator;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class StudentSerializedRepository extends InMemoryRepository<Long, Student> {

    private String fileName;

    public StudentSerializedRepository(Validator<Student> validator, String fileName) {
        super(validator);
        this.fileName = fileName;
        loadData();
    }

    private void writeData(){
        List<Student> list=new ArrayList<>();
        super.findAll().forEach(student->list.add(student));
        try(ObjectOutputStream os=new ObjectOutputStream(new FileOutputStream(fileName))){
            os.writeObject(list);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void loadData() {
        List<Student> list = new ArrayList<>();
        try(ObjectInputStream is = new ObjectInputStream(new FileInputStream(fileName))){
            list = (List<Student>) is.readObject();
            list.forEach(x->super.save(x));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Student save(Student entity) {
        Student student=super.save(entity);
        if(student==null)
            writeData();
        return student;
    }


}
