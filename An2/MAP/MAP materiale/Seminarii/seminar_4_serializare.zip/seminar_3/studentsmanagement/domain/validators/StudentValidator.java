package ubb.scs.map.ir.seminar.studentsmanagement.domain.validators;

import ubb.scs.map.ir.seminar.studentsmanagement.domain.Student;

public class StudentValidator implements Validator<Student> {
    @Override
    public void validate(Student entity) throws ValidationException {
        //TODO validate the student entoty
    }
}
