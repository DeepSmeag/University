﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sem11_12.model
{
    class Class1
    {
    }
}
